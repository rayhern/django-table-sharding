from django.apps import AppConfig


class ShardingConfig(AppConfig):
    name = 'sharding'
